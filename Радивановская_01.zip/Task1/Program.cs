﻿Console.WriteLine("Введите число a: ");
double a = Convert.ToDouble(Console.ReadLine());
Console.WriteLine("Введите число b: ");
double b = Convert.ToDouble(Console.ReadLine());

double rez = a / b;
Console.WriteLine($"Результат: {rez}");